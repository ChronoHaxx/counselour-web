/*! jQuery UI - v1.12.1 - 2016-09-15
* http://jqueryui.com
* Copyright jQuery Foundation and other contributors; Licensed  */
!function(){define(["jquery","./data","./disable-selection","./focusable","./form","./ie","./keycode","./labels","./jquery-1-7","./plugin","./safe-active-element","./safe-blur","./scroll-parent","./tabbable","./unique-id","./version"])}();